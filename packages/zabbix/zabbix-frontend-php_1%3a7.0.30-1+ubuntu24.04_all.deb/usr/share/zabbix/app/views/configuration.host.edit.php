<?php declare(strict_types = 0);
/*
** Copyright (C) 2001-2026 Zabbix SIA
**
** This program is free software: you can redistribute it and/or modify it under the terms of
** the GNU Affero General Public License as published by the Free Software Foundation, version 3.
**
** This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
** without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
** See the GNU Affero General Public License for more details.
**
** You should have received a copy of the GNU Affero General Public License along with this program.
** If not, see <https://www.gnu.org/licenses/>.
**/


/**
 * @var CView $this
 * @var array $data
 */

$this->addJsFile('items.js');
$this->addJsFile('multilineinput.js');
$this->includeJsFile('configuration.host.edit.js.php');

$cancel_button = (new CRedirectButton(_('Cancel'), (new CUrl('zabbix.php'))->setArgument('action', 'host.list')))
	->addClass('js-cancel');

$data += [
	'form_name' => 'host-form',
	'buttons' => ($data['hostid'] == 0)
		? [
			(new CSubmit('add', _('Add')))
				->removeAttribute('id'),
			$cancel_button
		]
		: [
			(new CSubmit('update', _('Update')))
				->removeAttribute('id'),
			(new CSimpleButton(_('Clone')))
				->onClick('view.clone();')
				->removeAttribute('id'),
			(new CSimpleButton(_('Delete')))
				->setAttribute('confirm', _('Delete selected host?'))
				->setAttribute('data-hostid', $data['hostid'])
				->onClick('view.delete(this.dataset.hostid, this);')
				->removeAttribute('id'),
			$cancel_button
		]
];

if ($data['warnings']) {
	foreach ($data['warnings'] as $msg) {
		CMessageHelper::addWarning($msg);
	}

	if (count($data['warnings']) > 1) {
		show_messages(null, _('Cloned host parameter values have been modified.'));
	}
	else {
		show_messages();
	}

	$data['warnings'] = null;
}

(new CHtmlPage())
	->setTitle(($data['hostid'] == 0) ? _('New host') : _('Host'))
	->setDocUrl(CDocHelper::getUrl(CDocHelper::DATA_COLLECTION_HOST_EDIT))
	->addItem(new CPartial('configuration.host.edit.html', $data))
	->show();

(new CScriptTag('view.init('.json_encode([
		'form_name' => $data['form_name'],
		'host_interfaces' => $data['host']['interfaces'],
		'proxy_groupid' => $data['host']['proxy_groupid'],
		'host_is_discovered' => ($data['host']['flags'] == ZBX_FLAG_DISCOVERY_CREATED)
	]).');'))
	->setOnDocumentReady()
	->show();
