<?php
/*
** Copyright (C) 2001-2026 Zabbix SIA
**
** This program is free software: you can redistribute it and/or modify it under the terms of
** the GNU Affero General Public License as published by the Free Software Foundation, version 3.
**
** This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
** without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
** See the GNU Affero General Public License for more details.
**
** You should have received a copy of the GNU Affero General Public License along with this program.
** If not, see <https://www.gnu.org/licenses/>.
**/


class CControllerFavoriteCreate extends CController {

	protected function checkInput() {
		$fields = [
			'object' =>		'fatal|required|in itemid,sysmapid',
			'objectid' =>	'fatal|required|id'
		];

		$ret = $this->validateInput($fields);

		if (!$ret) {
			$this->setResponse(new CControllerResponseData(['main_block' => '']));
		}

		return $ret;
	}

	protected function checkPermissions() {
		return ($this->getUserType() >= USER_TYPE_ZABBIX_USER);
	}

	protected function doAction() {
		$profile = [
			'itemid' => 'web.favorite.graphids',
			'sysmapid' => 'web.favorite.sysmapids'
		];

		$object = $this->getInput('object');
		$objectid = $this->getInput('objectid');

		$data = [];

		DBstart();
		$result = CFavorite::add($profile[$object], $objectid, $object);
		$result = DBend($result);

		$aria_label = $object === 'sysmapid' ? _('Remove map from the Favorite maps widget')
			: _('Remove graph from the Favorite graphs widget');

		if ($result) {
			$data['main_block'] = '
				var addrm_fav = document.getElementById("addrm_fav");

				if (addrm_fav !== null) {
					addrm_fav.setAttribute("aria-label", '.json_encode($aria_label).');
					addrm_fav.setAttribute("data-hintbox-contents", '.json_encode(_('Remove from favorites')).');
					addrm_fav.onclick = () => rm4favorites("'.$object.'", "'.$objectid.'");
					addrm_fav.classList.add("'.ZBX_ICON_STAR_FILLED.'");
					addrm_fav.classList.remove("'.ZBX_ICON_STAR.'");
					hintBox.hideHint(addrm_fav, true);
				}
			';
		}
		else {
			$data['main_block'] = '';
		}

		$this->setResponse(new CControllerResponseData($data));
	}
}
